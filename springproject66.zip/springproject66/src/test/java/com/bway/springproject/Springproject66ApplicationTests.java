package com.bway.springproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springproject66ApplicationTests {

	@Test
	void contextLoads() {
	}

}
