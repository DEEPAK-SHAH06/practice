package com.bway.springproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springproject66Application {

	public static void main(String[] args) {
		SpringApplication.run(Springproject66Application.class, args);
	}

}
